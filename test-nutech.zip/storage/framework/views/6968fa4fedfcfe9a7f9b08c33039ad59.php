<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header pb-0">
                        <div class="d-flex align-items-center">
                            <p class="mb-0">Data Produk</p>
                            <div class="ms-auto">
                                <button class="btn btn-transparant btn-sm dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Filter Data
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo e(route('produk.index')); ?>">Semua</a>
                                    </li>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item"
                                                href="<?php echo e(route('produk.kategori', $k->id)); ?>"><?php echo e($k->nama_kategori); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <a href="<?php echo e(route('exportexcel')); ?>" target="_blank"
                                    class="btn btn-success btn-sm">Export</a>
                                <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-primary btn-sm ms-2">Tambah</a>
                            </div>
                        </div>

                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-xs">No</th>
                                        <th class="text-uppercase text-xs">Image</th>
                                        <th class="text-uppercase text-xs">Nama Produk</th>
                                        <th class="text-uppercase text-xs">Kategori Produk</th>
                                        <th class="text-uppercase text-xs">Harga Beli </th>
                                        <th class="text-uppercase text-xs">Harga Jual</th>
                                        <th class="text-uppercase text-xs">Stok</th>
                                        <th class="text-uppercase text-xs">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="table_body">
                                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td align="center"><?php echo e($loop->iteration); ?></td>
                                            <td align="center"> <img src="<?php echo e(url('image/' . $data->image)); ?>" alt=""
                                                    srcset="" style="width: 30px;"></td>
                                            <td><?php echo e($data->nama_produk); ?></td>
                                            <td><?php echo e($data->nama_kategori); ?></td>
                                            <td><?php echo e(number_format($data->harga_beli, 0, ',', '.')); ?></td>
                                            <td><?php echo e(number_format($data->harga_jual, 0, ',', '.')); ?></td>

                                            <td><?php echo e($data->stok); ?></td>
                                            <td align="center">
                                                <a href="<?php echo e(route('produk.edit', $data->id)); ?>"
                                                    class="btn btn-link text-primary text-gradient px-1 mb-0"><i
                                                        class="fas fa-pencil-alt text-dark me-2"></i></a>
                                                <form id="delete-form-<?php echo e($data->id); ?>"
                                                    action="<?php echo e(route('produk.destroy', $data->id)); ?>" method="POST"
                                                    style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        class="btn btn-link text-danger text-gradient px-1 mb-0"
                                                        onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                                        <i class="far fa-trash-alt text-dark me-2"></i>
                                                    </button>
                                                </form>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\test-nutech\resources\views/admin/produk/index.blade.php ENDPATH**/ ?>